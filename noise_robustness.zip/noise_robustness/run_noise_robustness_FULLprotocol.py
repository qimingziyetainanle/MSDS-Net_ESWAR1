# -*- coding: utf-8 -*-
"""
run_noise_robustness_FULLprotocol.py

Reviewer-R1 noise-robustness experiment for MSDS-Net.

Source backbone
---------------
MSDSNet_v4p0_noiseRobustness_FULLprotocol_Backbone.py

Frozen items inherited from the verified FULL experiment
---------------------------------------------------------
- MSDS-Net architecture and score definition
- Protocol-v2.1 B1-R5 frozen 10-event benchmark
- 0%-55% clean training/reference
- 55%-70% evaluation interval
- final 30% physically excluded
- 30 epochs
- 10 formal seeds
- all loss weights / graph score weight / rho=0.8
- FULL threshold-selection code
- median_filter(size=3)
- Point-F1, Event-F1, Adj-F1, ROC-AUC, PR-AUC,
  Full-test FAR, EventRecall, Delay, Merge120 metrics

Noise protocol
--------------
For each formal seed:
1) Train ONE MSDS-Net model on the original CLEAN training data.
2) Determine ONE threshold using the exact frozen FULL protocol.
3) Inject the frozen B1-R5 anomalies exactly as in FULL.
4) Add Gaussian sensor noise to the seven RAW measurement channels:
       x_noisy(t,j) = x(t,j) + alpha * sigma_j * epsilon(t,j)
   where sigma_j is computed from the CLEAN 0%-55% reference segment.
5) Recompute engineered features and transform them with the SAME clean scaler.
6) Evaluate the SAME trained model at all noise levels using the SAME threshold.

A single epsilon realization is reused for every alpha of the same seed.
Therefore the noise levels are nested rather than independently resampled.

IMPORTANT:
alpha=0 must reproduce the corresponding FULL result (subject only to
floating-point determinism). If it does not, stop before using the experiment.

Direct PyCharm run:
    python run_noise_robustness_FULLprotocol.py
"""

import gc
import json
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
import torch
from scipy.ndimage import median_filter
from torch.utils.data import DataLoader

import MSDSNet_v4p0_noiseRobustness_FULLprotocol_Backbone as base


# ============================================================
# FORMAL SETTINGS
# ============================================================

# Noise amplitude as a fraction of each raw channel's CLEAN training std.
NOISE_LEVELS = [
    0.00,
    0.01,
    0.03,
    0.05,
    0.08,
    0.10,
    0.15,
    0.20,
    0.25,
    0.30
]

FORMAL_SEEDS = [
    42,
    2024,
    2025,
    2026,
    2027,
    2028,
    2029,
    2030,
    2031,
    2032,
]

# Independent RNG stream for measurement-noise realizations.
NOISE_SEED_OFFSET = 700000

OUTPUT_ROOT = Path("07_noise_robustness_results_FULLprotocol")

# Recommended first run:
# True  -> only seed 42, but still evaluates ALL noise levels after one 30-epoch training.
# False -> formal 10-seed experiment.
QUICK_TEST = False

# Resume works at the SEED level. A completed seed JSON skips retraining that seed.
RESUME = True


# ============================================================
# Utilities
# ============================================================

def json_default(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (pd.Timestamp,)):
        return obj.isoformat()
    return str(obj)


def sample_std(values) -> float:
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if x.size <= 1:
        return 0.0
    return float(np.std(x, ddof=1))


def alpha_tag(alpha: float) -> str:
    return f"{float(alpha):.3f}".replace(".", "p")


def make_eval_loader(
    eval_arrays: Dict[str, np.ndarray],
    cfg,
    device: torch.device,
) -> DataLoader:
    n = len(next(iter(eval_arrays.values())))
    starts = base.make_start_indices(
        n,
        cfg.seq_len,
        cfg.stride,
        end_limit=None,
    )
    return DataLoader(
        base.WindowDataset(eval_arrays, starts, cfg.seq_len),
        batch_size=cfg.batch_size,
        shuffle=False,
        drop_last=False,
        num_workers=cfg.num_workers,
        pin_memory=(device.type == "cuda"),
    )


def freeze_full_cfg():
    """
    Use the exact formal settings from the uploaded FULL script.

    NOTE:
    The model implementation references base.CFG internally in a few places,
    so we deliberately use the SAME global Config object instead of a deepcopy.
    """
    cfg = base.CFG

    cfg.lambda_trend = 1.75
    cfg.lambda_dist = 0.10
    cfg.lambda_res = 0.0008
    cfg.lambda_graph = 0.018
    cfg.a_residual_mix = 0.8
    cfg.graph_score_weight = 0.031
    cfg.threshold_quantile = 0.99

    cfg.epochs = 30
    cfg.run_ablation = False
    cfg.run_injection_eval = True
    cfg.show_figures = False
    cfg.save_figures = False
    cfg.make_threshold_sensitivity_figure = False

    return cfg


def prepare_frozen_data(cfg):
    """
    Reproduce the FULL data construction exactly, before adding noise.
    """
    script_dir = Path(__file__).resolve().parent
    parent_dir = script_dir.parent

    if not Path(cfg.temperature_file).exists():
        candidates = [
            script_dir / "930T.csv",
            parent_dir / "930T.csv",
        ]
        for p in candidates:
            if p.exists():
                cfg.temperature_file = str(p)
                break

    if not Path(cfg.vi_file).exists():
        candidates = [
            script_dir / "930V.csv",
            parent_dir / "930V.csv",
        ]
        for p in candidates:
            if p.exists():
                cfg.vi_file = str(p)
                break

    raw_full = base.load_raw_inputs(cfg)
    full_n = len(raw_full)

    train_end = int(full_n * 0.55)
    eval_end = int(full_n * 0.70)
    eval_start = int(train_end)

    raw_df = raw_full.iloc[:eval_end].copy().reset_index(drop=True)
    del raw_full

    n = len(raw_df)

    # Clean features/scaler: identical to FULL.
    feature_df, subspace_cols, feature_cols = base.add_engineered_features(raw_df)
    scaled_df, scaler = base.scale_features(
        feature_df,
        feature_cols,
        train_end,
        scaler=None,
    )

    # Frozen anomaly injection: identical to FULL.
    injected_raw, labels, events_df = base.inject_synthetic_anomalies(
        raw_df,
        train_end,
        cfg,
    )

    eval_mask = np.zeros(n, dtype=bool)
    eval_mask[eval_start:eval_end] = True

    # Channel-wise sensor-noise scale from clean 0%-55% ONLY.
    channel_scales = base.compute_clean_training_noise_scale(
        raw_df,
        train_end,
    )

    return {
        "full_n": int(full_n),
        "train_end": int(train_end),
        "eval_start": int(eval_start),
        "eval_end": int(eval_end),
        "raw_df": raw_df,
        "scaled_df": scaled_df,
        "scaler": scaler,
        "subspace_cols": subspace_cols,
        "feature_cols": feature_cols,
        "injected_raw": injected_raw,
        "labels": labels,
        "events_df": events_df,
        "eval_mask": eval_mask,
        "n": int(n),
        "channel_scales": channel_scales,
    }


# ============================================================
# One seed: ONE training + multiple noise evaluations
# ============================================================

def run_one_seed(
    seed: int,
    cfg,
    device: torch.device,
    data: Dict,
) -> List[Dict]:

    base.set_seed(seed)
    cfg.seed = int(seed)

    out_seed_dir = OUTPUT_ROOT / f"seed_{seed}"
    out_seed_dir.mkdir(parents=True, exist_ok=True)

    # --------------------------------------------------------
    # Build/train FULL model on CLEAN data only.
    # --------------------------------------------------------
    model, variant_subspace_cols = base.make_model_for_variant(
        "FULL",
        data["subspace_cols"],
        data["feature_cols"],
        cfg,
        device,
    )

    train_arrays = base.build_subspace_arrays(
        data["scaled_df"],
        variant_subspace_cols,
    )

    # Use a temporary clean eval array only to obtain FULL's train_eval_loader.
    # No noise ever enters training.
    train_loader, _, train_eval_loader = base.build_loaders_for_arrays(
        train_arrays,
        train_arrays,
        data["train_end"],
        cfg,
        device,
    )

    base.train_model(
        model,
        train_loader,
        cfg,
        device,
        epochs=cfg.epochs,
        title=f"NOISE_FULL_seed_{seed}",
    )

    # --------------------------------------------------------
    # ONE threshold from the exact FULL protocol.
    # This threshold is held fixed across all noise levels.
    # --------------------------------------------------------
    train_result = base.aggregate_scores(
        model,
        train_eval_loader,
        n_points=data["n"],
        cfg=cfg,
        device=device,
        collect_components=False,
    )

    threshold = base.choose_threshold(
        train_score=train_result["score"][:data["train_end"]],
        quantile=cfg.threshold_quantile,
        far_target=0.05,
        val_score=train_result["score"][data["train_end"]:],
        val_label=data["labels"][data["train_end"]:],
    )

    # One deterministic Gaussian realization per formal seed.
    noise_seed = int(NOISE_SEED_OFFSET + int(seed))
    epsilon = base.make_standard_gaussian_noise(
        data["n"],
        seed=noise_seed,
    )

    seed_rows: List[Dict] = []

    for alpha in NOISE_LEVELS:
        print(
            f"\n[Noise eval] seed={seed} | alpha={alpha:.3f} "
            f"| fixed threshold={threshold:.6f}",
            flush=True,
        )

        # ----------------------------------------------------
        # Frozen anomalies first, then raw sensor noise.
        # ----------------------------------------------------
        noisy_injected_raw = base.add_channelwise_gaussian_sensor_noise(
            data["injected_raw"],
            alpha=float(alpha),
            channel_scales=data["channel_scales"],
            epsilon=epsilon,
        )

        # Engineered features are recomputed AFTER raw noise.
        noisy_feature_df, _, _ = base.add_engineered_features(
            noisy_injected_raw
        )

        # Transform with the CLEAN scaler fitted once above.
        noisy_scaled_df, _ = base.scale_features(
            noisy_feature_df,
            data["feature_cols"],
            data["train_end"],
            scaler=data["scaler"],
        )

        eval_arrays = base.build_subspace_arrays(
            noisy_scaled_df,
            variant_subspace_cols,
        )

        eval_loader = make_eval_loader(
            eval_arrays,
            cfg,
            device,
        )

        eval_result = base.aggregate_scores(
            model,
            eval_loader,
            n_points=data["n"],
            cfg=cfg,
            device=device,
            collect_components=False,
        )

        # Exact FULL post-processing.
        eval_result["score"] = median_filter(
            eval_result["score"],
            size=3,
        )

        met = base.compute_event_adjusted_metrics(
            data["labels"],
            eval_result["score"],
            threshold,
            data["events_df"],
            data["eval_mask"],
        )

        row = dict(met)
        row.update({
            "NoiseAlpha": float(alpha),
            "NoisePercentOfTrainStd": float(alpha * 100.0),
            "NoiseSeed": int(noise_seed),
            "Threshold": float(threshold),
            "EvalPoints": int(data["eval_mask"].sum()),
            "Seed": int(seed),
        })

        seed_rows.append(row)

        # Per-level score file.
        level_dir = out_seed_dir / f"noise_{alpha_tag(alpha)}"
        level_dir.mkdir(parents=True, exist_ok=True)

        score_df = pd.DataFrame({
            "time": noisy_feature_df["time"],
            "label": data["labels"].astype(int),
            "eval_mask": data["eval_mask"].astype(int),
            "score": eval_result["score"],
            "pred": (eval_result["score"] > threshold).astype(int),
            "threshold": float(threshold),
            "noise_alpha": float(alpha),
            "noise_percent_of_train_std": float(alpha * 100.0),
        })

        score_df.to_csv(
            level_dir / f"seed_{seed}_noise_{alpha_tag(alpha)}_scores.csv",
            index=False,
            encoding="utf-8-sig",
        )

        print(
            f"[seed={seed} | alpha={alpha:.3f}] "
            f"F1={row['PointF1']:.4f} | "
            f"EventF1={row['EventF1']:.4f} | "
            f"AdjF1={row['AdjF1']:.4f} | "
            f"ROC={row['ROC_AUC']:.4f} | "
            f"AP={row['PR_AUC_AP']:.4f} | "
            f"FAR={row['FullFAR']:.4f} | "
            f"EventRecall={row['EventRecall']:.4f} | "
            f"Delay={row['DelayMeanMin']:.2f}",
            flush=True,
        )

        del eval_loader, eval_result, eval_arrays
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    # Save one completion marker per seed for safe resume.
    with open(
        out_seed_dir / "seed_noise_results.json",
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            seed_rows,
            f,
            ensure_ascii=False,
            indent=2,
            default=json_default,
        )

    del model, train_loader, train_eval_loader, train_result, train_arrays
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    return seed_rows


# ============================================================
# Summary tables
# ============================================================

SUMMARY_METRICS = [
    "PointPrecision",
    "PointRecall",
    "PointF1",
    "EventPrecision",
    "EventRecall",
    "EventF1",
    "AdjPrecision",
    "AdjRecall",
    "AdjF1",
    "ROC_AUC",
    "PR_AUC_AP",
    "FullFAR",
    "MDR",
    "DelayMeanMin",
    "Merge120EventF1",
    "Threshold",
]


def build_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for alpha in NOISE_LEVELS:
        g = df[np.isclose(
            pd.to_numeric(df["NoiseAlpha"], errors="coerce").to_numpy(dtype=float),
            float(alpha)
        )].copy()

        if g.empty:
            continue

        item = {
            "NoiseAlpha": float(alpha),
            "NoisePercentOfTrainStd": float(alpha * 100.0),
            "Runs": int(len(g)),
        }

        for metric in SUMMARY_METRICS:
            if metric not in g.columns:
                continue

            vals = pd.to_numeric(g[metric], errors="coerce").to_numpy(dtype=float)
            vals = vals[np.isfinite(vals)]

            if vals.size == 0:
                item[f"{metric}_mean"] = np.nan
                item[f"{metric}_std"] = np.nan
            else:
                item[f"{metric}_mean"] = float(np.mean(vals))
                item[f"{metric}_std"] = sample_std(vals)

        rows.append(item)

    return pd.DataFrame(rows)


def build_formatted_summary(summary: pd.DataFrame) -> pd.DataFrame:
    paper_metrics = [
        ("Point-F1", "PointF1", 4),
        ("Event-F1", "EventF1", 4),
        ("Adj-F1", "AdjF1", 4),
        ("ROC-AUC", "ROC_AUC", 4),
        ("PR-AUC", "PR_AUC_AP", 4),
        ("Full-test FAR", "FullFAR", 4),
        ("EventRecall", "EventRecall", 4),
        ("Delay(min)", "DelayMeanMin", 2),
    ]

    rows = []

    for _, r in summary.iterrows():
        item = {
            "Noise level (alpha)": float(r["NoiseAlpha"]),
            "Noise (% train std)": float(r["NoisePercentOfTrainStd"]),
            "Runs": int(r["Runs"]),
        }

        for display, key, digits in paper_metrics:
            mk = f"{key}_mean"
            sk = f"{key}_std"

            if mk in summary.columns and sk in summary.columns:
                m = float(r[mk])
                s = float(r[sk])
                item[display] = f"{m:.{digits}f}±{s:.{digits}f}"

        rows.append(item)

    return pd.DataFrame(rows)


# ============================================================
# Main
# ============================================================

def main():
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    base.set_paper_style()
    cfg = freeze_full_cfg()
    cfg.output_dir = str(OUTPUT_ROOT)

    device = base.get_training_device(cfg)
    data = prepare_frozen_data(cfg)

    # Static protocol audit before expensive training.
    static_model, _ = base.make_model_for_variant(
        "FULL",
        data["subspace_cols"],
        data["feature_cols"],
        cfg,
        device,
    )
    param_count = int(sum(
        p.numel() for p in static_model.parameters() if p.requires_grad
    ))
    del static_model

    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    if param_count != 264001:
        raise RuntimeError(
            f"Noise robustness audit failed: "
            f"parameter_count={param_count}, expected=264001."
        )

    if len(data["events_df"]) != 10:
        raise RuntimeError(
            f"Noise robustness audit failed: "
            f"event_count={len(data['events_df'])}, expected=10."
        )

    if int(data["labels"][data["eval_mask"]].sum()) != 1200:
        raise RuntimeError(
            "Noise robustness audit failed: positive validation points != 1200."
        )

    audit = {
        "experiment": "MSDS-Net_R1_NOISE_ROBUSTNESS_FULL_PROTOCOL",
        "source_protocol": base.PROTOCOL_VERSION_V4,
        "noise_type": "zero_mean_channelwise_Gaussian_sensor_noise",
        "noise_formula": "x_noisy(t,j)=x(t,j)+alpha*sigma_j*epsilon(t,j)",
        "sigma_source": "clean_0_55_training_reference_only",
        "noise_application_order": (
            "frozen_anomaly_injection -> raw_sensor_noise -> "
            "engineered_features -> clean_scaler_transform"
        ),
        "same_noise_realization_across_levels_within_seed": True,
        "model_training": "clean_only_once_per_seed",
        "threshold": "one_clean_FULL_protocol_threshold_per_seed_fixed_across_noise_levels",
        "noise_levels": list(NOISE_LEVELS),
        "formal_seeds": list(FORMAL_SEEDS),
        "epochs": int(cfg.epochs),
        "rho": float(cfg.a_residual_mix),
        "lambda_trend": float(cfg.lambda_trend),
        "lambda_dist": float(cfg.lambda_dist),
        "lambda_res": float(cfg.lambda_res),
        "lambda_graph": float(cfg.lambda_graph),
        "graph_score_weight": float(cfg.graph_score_weight),
        "threshold_quantile": float(cfg.threshold_quantile),
        "parameter_count": int(param_count),
        "event_count": int(len(data["events_df"])),
        "positive_points": int(data["labels"][data["eval_mask"]].sum()),
        "raw_noise_channels": list(base.NOISE_RAW_COLS),
        "channel_train_std": dict(data["channel_scales"]),
        "model_structure_changed": False,
        "loss_changed": False,
        "injection_protocol_changed": False,
        "metric_protocol_changed": False,
    }

    with open(
        OUTPUT_ROOT / "noise_robustness_protocol_audit.json",
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            audit,
            f,
            ensure_ascii=False,
            indent=2,
            default=json_default,
        )

    seeds = [42] if QUICK_TEST else list(FORMAL_SEEDS)

    if QUICK_TEST:
        print(
            "\n[QUICK_TEST=True] One 30-epoch clean training for seed=42, "
            "then ALL noise levels are evaluated with that same model.\n"
            "If alpha=0 matches FULL seed=42, set QUICK_TEST=False "
            "for the formal 10-seed run.\n",
            flush=True,
        )

    all_rows: List[Dict] = []

    for seed in seeds:
        seed_json = OUTPUT_ROOT / f"seed_{seed}" / "seed_noise_results.json"

        if RESUME and seed_json.exists():
            print(f"[RESUME] Skip completed seed={seed}", flush=True)

            with open(seed_json, "r", encoding="utf-8") as f:
                rows = json.load(f)

            all_rows.extend(rows)
            continue

        print("\n" + "=" * 90)
        print(f"NOISE ROBUSTNESS | formal seed={seed}")
        print("=" * 90, flush=True)

        rows = run_one_seed(
            seed=seed,
            cfg=cfg,
            device=device,
            data=data,
        )
        all_rows.extend(rows)

        # Incremental master JSON after every completed seed.
        with open(
            OUTPUT_ROOT / "noise_robustness_all_results.json",
            "w",
            encoding="utf-8",
        ) as f:
            json.dump(
                all_rows,
                f,
                ensure_ascii=False,
                indent=2,
                default=json_default,
            )

    df = pd.DataFrame(all_rows)

    if df.empty:
        raise RuntimeError("No noise robustness results were produced.")

    df.to_csv(
        OUTPUT_ROOT / "noise_robustness_seedwise_results.csv",
        index=False,
        encoding="utf-8-sig",
    )

    summary = build_summary(df)
    summary.to_csv(
        OUTPUT_ROOT / "noise_robustness_mean_std.csv",
        index=False,
        encoding="utf-8-sig",
    )

    formatted = build_formatted_summary(summary)
    formatted.to_csv(
        OUTPUT_ROOT / "noise_robustness_mean_std_formatted.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Alpha=0 audit table: this is the row to compare against the frozen FULL experiment.
    alpha0 = df[np.isclose(
        pd.to_numeric(df["NoiseAlpha"], errors="coerce").to_numpy(dtype=float),
        0.0
    )].copy()

    alpha0.to_csv(
        OUTPUT_ROOT / "alpha0_FULL_identity_check_seedwise.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print("\n" + "=" * 90)
    print("NOISE ROBUSTNESS FINISHED")
    print("=" * 90)
    print("Seedwise :", OUTPUT_ROOT / "noise_robustness_seedwise_results.csv")
    print("Mean±std :", OUTPUT_ROOT / "noise_robustness_mean_std.csv")
    print("Formatted:", OUTPUT_ROOT / "noise_robustness_mean_std_formatted.csv")
    print("Audit    :", OUTPUT_ROOT / "noise_robustness_protocol_audit.json")
    print("alpha=0  :", OUTPUT_ROOT / "alpha0_FULL_identity_check_seedwise.csv")

    print(
        "\nIMPORTANT: before using the formal table, verify that alpha=0 "
        "reproduces the frozen FULL results."
    )


if __name__ == "__main__":
    main()
