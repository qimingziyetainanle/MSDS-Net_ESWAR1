# -*- coding: utf-8 -*-

"""
Paired statistical significance test for MSDS-Net ablation study

Test:
    Wilcoxon signed-rank test

Compare:
    MSDS-Net vs each ablation variant

Metrics:
    EventF1
    AdjF1
    PointF1

Output:
    ablation_statistical_test.csv
"""


import pandas as pd
import numpy as np
from scipy.stats import wilcoxon


FULL_FILE = r"C:\Users\MSI-NB\PycharmProjects\A1\930eswaR1\04ablation\statistic\MSDSNet_R1_full_10seed_seedwise_results.csv"

ABLATION_FILE = r"C:\Users\MSI-NB\PycharmProjects\A1\930eswaR1\04ablation\statistic\ablation_seedwise_results.csv"


OUTPUT_FILE = "ablation_statistical_test.csv"



def wilcoxon_test(a, b):

    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)

    # remove nan
    mask = np.isfinite(a) & np.isfinite(b)

    a = a[mask]
    b = b[mask]

    if len(a) < 3:
        return np.nan

    try:
        stat, p = wilcoxon(
            a,
            b,
            alternative="two-sided"
        )
    except Exception:
        p = 1.0

    return p



def main():

    full = pd.read_csv(FULL_FILE)

    abl = pd.read_csv(ABLATION_FILE)


    # ============================
    # align seeds
    # ============================

    full = full.sort_values("Seed")


    metrics = [
        "PointF1",
        "EventF1",
        "AdjF1",
        "FullFAR",
        "PR_AUC"
    ]


    variants = [
        v for v in abl["variant"].unique()
    ]


    results = []


    for variant in variants:

        sub = abl[
            abl["variant"] == variant
        ].copy()

        sub = sub.sort_values("seed")


        # ensure same seed order
        merged = pd.merge(
            full[["Seed"] + metrics],
            sub[["seed"] + metrics],
            left_on="Seed",
            right_on="seed",
            suffixes=("_full", "_abl")
        )


        row = {
            "Comparison":
                "MSDS-Net vs " + variant
        }


        for m in metrics:

            p = wilcoxon_test(
                merged[f"{m}_full"],
                merged[f"{m}_abl"]
            )

            row[m+"_p_value"] = p


        results.append(row)


    df = pd.DataFrame(results)


    # significance mark

    for c in df.columns:

        if "p_value" in c:

            df[c+"_sig"] = df[c].apply(
                lambda x:
                    "***" if x < 0.001 else
                    "**" if x < 0.01 else
                    "*" if x < 0.05 else
                    "ns"
            )


    df.to_csv(
        OUTPUT_FILE,
        index=False,
        encoding="utf-8-sig"
    )


    print("="*60)
    print("Finished")
    print(df)
    print("="*60)



if __name__ == "__main__":
    main()