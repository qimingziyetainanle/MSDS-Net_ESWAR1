# -*- coding: utf-8 -*-
"""Final MSDS-Net R1 ablation runner.
Runs 8 ablation variants only (no FULL).
"""

import json
import importlib.util
from pathlib import Path
from copy import deepcopy
import numpy as np
import pandas as pd

FULL_FILE = "MSDSNet_v4.0_AblationWrapper_Backbone.py"

VARIANTS = [
    "w/o Subspace",
    "w/o Separation",
    "w/o MQ-RGA",
    "w/o Gate",
    "w/o EdgeBias",
    "MQ-RGA-to-SE",
    "Gate-to-fixed-fusion",
    "EdgeBias-to-vanilla-residual",
]


def load_full_module():
    path = Path(FULL_FILE)
    spec = importlib.util.spec_from_file_location("msds_full", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def save_outputs(records, scores, out_dir):
    out_dir.mkdir(exist_ok=True, parents=True)

    df = pd.DataFrame(records)
    df.to_csv(out_dir / "ablation_seedwise_results.csv",
              index=False, encoding="utf-8-sig")

    metric_cols = [
        c for c in df.columns
        if c not in ["variant", "seed"]
        and pd.api.types.is_numeric_dtype(df[c])
    ]

    summary = []
    for name, g in df.groupby("variant"):
        row = {"variant": name}
        for c in metric_cols:
            row[c + "_mean"] = float(g[c].mean())
            row[c + "_std"] = float(g[c].std(ddof=1))
        summary.append(row)

    pd.DataFrame(summary).to_csv(
        out_dir / "ablation_mean_std.csv",
        index=False,
        encoding="utf-8-sig")

    files = []
    for s in scores:
        fname = s["variant"].replace("/", "_").replace(">", "to")
        fname = f"{fname}_seed_{s['seed']}_score.npy"
        np.save(out_dir / fname, s["score"])
        files.append(fname)

    with open(out_dir / "ablation_report.json", "w", encoding="utf-8") as f:
        json.dump({
            "experiment": "MSDS-Net_R1_ABLATION_8_VARIANTS_10SEEDS",
            "variants": VARIANTS,
            "seedwise_results": records,
            "score_files": files
        }, f, ensure_ascii=False, indent=2)


def main():
    full = load_full_module()

    if not hasattr(full, "run_single_experiment"):
        raise RuntimeError("Missing run_single_experiment")

    out_dir = Path("04ablation_outputs")

    records = []
    scores = []

    seeds = getattr(full, "SEEDS_10",
                    [42, 2024, 2025, 2026, 2027,
                     2028, 2029, 2030, 2031, 2032])

    for variant in VARIANTS:
        for seed in seeds:

            print("=" * 50)
            print("RUN", variant, "seed", seed)

            cfg = deepcopy(full.CFG)
            cfg.seed = seed

            safe_variant = (
                variant
                .replace("/", "_")
                .replace(">", "to")
                .replace("<", "to")
            )

            cfg.output_dir = str(
                out_dir / safe_variant
            )

            # 加这里
            seed_dir = Path(cfg.output_dir)
            score_file = seed_dir / f"seed_{seed}_scores.csv"

            if score_file.exists():
                print(f"[SKIP] {variant} seed={seed}")
                continue

            result = full.run_single_experiment(
                cfg=cfg,
                seed=seed,
                variant=variant
            )

            row = {
                "variant": variant,
                "seed": seed
            }

            for k, v in result.items():
                if k != "score":
                    row[k] = v

            records.append(row)

            if "score" in result:
                score_records.append(
                    {
                        "variant": variant,
                        "seed": seed,
                        "score": np.asarray(result["score"])
                    }
                )

    save_outputs(records, scores, out_dir)


if __name__ == "__main__":
    main()
