# -*- coding: utf-8 -*-
"""
run_rho_control_FULLprotocol.py

Reviewer-R1 rho disentanglement control experiment for MSDS-Net.

This runner uses:
    MSDSNet_v4p0_rhoControl_FULLprotocol_Backbone.py

Formal design
-------------
rho values:
    0.5, 0.8, 1.0

control modes:
1) coupled
   rho -> residual mixing + reconstruction/sparsity losses + MQ-RGA

2) recres_fixed
   reconstruction + residual-sparsity loss paths are fixed at rho_ref=0.8;
   tested rho still acts on the direct residual path and MQ-RGA.

3) recres_graph_fixed
   reconstruction/sparsity + MQ-RGA are fixed at rho_ref=0.8;
   tested rho acts only on the direct residual-score path.

All other settings are inherited from the verified FULL protocol:
- frozen B1-R5 10-event benchmark
- 30 epochs
- 10 seeds
- same threshold/evaluation pipeline
- same model structure and default hyperparameters

Outputs
-------
06_rho_control_results_FULLprotocol/
    <mode>_rho_<rho>/
        seed_<seed>/
            seed_<seed>_scores.csv
            seed_result.json
    rho_control_seedwise_results.csv
    rho_control_mean_std.csv
    rho_control_mean_std_formatted.csv
    rho_control_all_results.json
    rho_control_protocol_audit.json
    rho_ref_identity_audit.json

Safe resume:
Existing seed_result.json files are loaded and skipped.
"""

import copy
import json
import gc
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
import torch

import MSDSNet_v4p0_rhoControl_FULLprotocol_Backbone as base


# ============================================================
# USER SETTINGS
# ============================================================

RHO_REF = 0.80

RHO_VALUES = [
    0.0,
    0.1,
    0.2,
    0.3,
    0.4,
    0.5,
    0.6,
    0.7,
    0.8,
    0.9,
    1.0,
]

CONTROL_MODES = [
    "recres_graph_fixed",
]

FORMAL_SEEDS = [
    42,
    2024,
    2025,
    2026,
    2027,
    2028,
    2029,
    2030,
    2031,
    2032,
]

OUTPUT_ROOT = Path("06_rho_control_results_FULLprotocol")

# First execution can be changed to True for a one-run pipeline check.
# QUICK_TEST=True -> coupled, rho=0.8, seed=42 only, still 30 epochs.
QUICK_TEST = False

# If True, completed seed_result.json files are not trained again.
RESUME = True


# ============================================================
# Utilities
# ============================================================

def json_default(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (pd.Timestamp,)):
        return obj.isoformat()
    return str(obj)


def sample_std(values) -> float:
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if x.size <= 1:
        return 0.0
    return float(np.std(x, ddof=1))


def rho_tag(rho: float) -> str:
    return f"{float(rho):.2f}".replace(".", "p")


def seed_result_path(mode: str, rho: float, seed: int) -> Path:
    return (
        OUTPUT_ROOT
        / f"{mode}_rho_{rho_tag(rho)}"
        / f"seed_{seed}"
        / "seed_result.json"
    )


def load_existing(path: Path) -> Dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ============================================================
# One formal run
# ============================================================

def run_one(mode: str, rho: float, seed: int) -> Dict:
    if mode not in base.RHO_CONTROL_DESCRIPTION:
        raise ValueError(f"Unknown mode: {mode}")

    cfg = copy.deepcopy(base.CFG)

    # --------------------------------------------------------
    # ONLY rho-control variables are changed here.
    # --------------------------------------------------------
    cfg.rho_control_mode = str(mode)
    cfg.rho_ref = float(RHO_REF)
    cfg.a_residual_mix = float(rho)
    cfg.seed = int(seed)

    # --------------------------------------------------------
    # Freeze the verified formal protocol.
    # --------------------------------------------------------
    cfg.epochs = 30
    cfg.run_ablation = False
    cfg.run_injection_eval = True
    cfg.show_figures = False
    cfg.save_figures = False
    cfg.make_threshold_sensitivity_figure = False

    run_dir = (
        OUTPUT_ROOT
        / f"{mode}_rho_{rho_tag(rho)}"
        / f"seed_{seed}"
    )
    run_dir.mkdir(parents=True, exist_ok=True)
    cfg.output_dir = str(run_dir)

    print("\n" + "=" * 88)
    print(
        f"RHO CONTROL | mode={mode} | rho={rho:.2f} | "
        f"rho_ref={RHO_REF:.2f} | seed={seed}"
    )
    print(
        "Frozen CFG | "
        f"epochs={cfg.epochs}, "
        f"lambda_trend={cfg.lambda_trend}, "
        f"lambda_dist={cfg.lambda_dist}, "
        f"lambda_res={cfg.lambda_res}, "
        f"lambda_graph={cfg.lambda_graph}, "
        f"graph_score_weight={cfg.graph_score_weight}, "
        f"threshold_q={cfg.threshold_quantile}"
    )
    print("=" * 88, flush=True)

    met = base.run_full_experiment(cfg)

    result = dict(met)
    result.update({
        "ControlMode": str(mode),
        "ControlDescription": base.RHO_CONTROL_DESCRIPTION[mode],
        "rho": float(rho),
        "rho_ref": float(RHO_REF),
        "Seed": int(seed),
        "Epochs": int(cfg.epochs),
        "lambda_trend": float(cfg.lambda_trend),
        "lambda_dist": float(cfg.lambda_dist),
        "lambda_res": float(cfg.lambda_res),
        "lambda_graph": float(cfg.lambda_graph),
        "graph_score_weight": float(cfg.graph_score_weight),
        "threshold_quantile": float(cfg.threshold_quantile),
    })

    out_json = run_dir / "seed_result.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(
            result,
            f,
            ensure_ascii=False,
            indent=2,
            default=json_default
        )

    return result


# ============================================================
# Summary
# ============================================================

SUMMARY_METRICS = [
    "PointPrecision",
    "PointRecall",
    "PointF1",
    "EventPrecision",
    "EventRecall",
    "EventF1",
    "AdjPrecision",
    "AdjRecall",
    "AdjF1",
    "ROC_AUC",
    "PR_AUC_AP",
    "FullFAR",
    "MDR",
    "DelayMeanMin",
    "Merge120EventF1",
    "Threshold",
]


def build_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict] = []

    for mode in CONTROL_MODES:
        for rho in RHO_VALUES:
            g = df[
                (df["ControlMode"] == mode)
                & np.isclose(df["rho"].astype(float), float(rho))
            ].copy()

            if g.empty:
                continue

            row = {
                "ControlMode": mode,
                "ControlDescription": base.RHO_CONTROL_DESCRIPTION[mode],
                "rho": float(rho),
                "rho_ref": float(RHO_REF),
                "Runs": int(len(g)),
            }

            for m in SUMMARY_METRICS:
                if m not in g.columns:
                    continue
                vals = pd.to_numeric(g[m], errors="coerce").to_numpy(dtype=float)
                vals = vals[np.isfinite(vals)]
                if vals.size == 0:
                    row[f"{m}_mean"] = np.nan
                    row[f"{m}_std"] = np.nan
                else:
                    row[f"{m}_mean"] = float(np.mean(vals))
                    row[f"{m}_std"] = sample_std(vals)

            rows.append(row)

    return pd.DataFrame(rows)


def build_formatted_summary(summary: pd.DataFrame) -> pd.DataFrame:
    paper_metrics = [
        ("Point-F1", "PointF1", 4),
        ("Event-F1", "EventF1", 4),
        ("Adj-F1", "AdjF1", 4),
        ("ROC-AUC", "ROC_AUC", 4),
        ("PR-AUC", "PR_AUC_AP", 4),
        ("Full-test FAR", "FullFAR", 4),
        ("EventRecall", "EventRecall", 4),
        ("Delay(min)", "DelayMeanMin", 2),
    ]

    rows = []

    for _, r in summary.iterrows():
        item = {
            "ControlMode": r["ControlMode"],
            "rho": r["rho"],
            "Runs": int(r["Runs"]),
        }

        for display, key, digits in paper_metrics:
            mk = f"{key}_mean"
            sk = f"{key}_std"
            if mk in summary.columns and sk in summary.columns:
                m = float(r[mk])
                s = float(r[sk])
                item[display] = f"{m:.{digits}f}±{s:.{digits}f}"

        rows.append(item)

    return pd.DataFrame(rows)


# ============================================================
# Critical identity audit at rho_ref
# ============================================================

def rho_ref_identity_audit(df: pd.DataFrame) -> Dict:
    """
    At rho == rho_ref, A_test == A_ref.
    Therefore all three control modes should reduce to the same computation.

    With deterministic seeds, formal metrics should agree up to numerical noise.
    This is an internal validity check for the control implementation.
    """
    check_metrics = [
        "PointF1",
        "EventF1",
        "AdjF1",
        "ROC_AUC",
        "PR_AUC_AP",
        "FullFAR",
        "EventRecall",
        "DelayMeanMin",
        "Threshold",
    ]

    sub = df[np.isclose(df["rho"].astype(float), RHO_REF)].copy()

    audit = {
        "rho_ref": float(RHO_REF),
        "expected_identity": True,
        "per_seed_max_abs_diff": {},
        "overall_max_abs_diff": None,
        "passed_tolerance_1e-8": None,
    }

    if sub.empty:
        return audit

    overall = 0.0

    for seed in FORMAL_SEEDS:
        s = sub[sub["Seed"].astype(int) == int(seed)]
        if len(s) < 2:
            continue

        diffs = []

        for m in check_metrics:
            if m not in s.columns:
                continue
            vals = pd.to_numeric(s[m], errors="coerce").dropna().to_numpy(dtype=float)
            if vals.size <= 1:
                continue
            diffs.append(float(np.max(vals) - np.min(vals)))

        max_diff = max(diffs) if diffs else 0.0
        audit["per_seed_max_abs_diff"][str(seed)] = max_diff
        overall = max(overall, max_diff)

    audit["overall_max_abs_diff"] = float(overall)
    audit["passed_tolerance_1e-8"] = bool(overall <= 1e-8)
    return audit


# ============================================================
# Main
# ============================================================

def main():
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    # Formal self-audit of experimental settings.
    protocol_audit = {
        "experiment": "Reviewer_R1_rho_disentanglement_control",
        "backbone": "MSDSNet_v4p0_rhoControl_FULLprotocol_Backbone.py",
        "rho_ref": float(RHO_REF),
        "rho_values": list(RHO_VALUES),
        "control_modes": list(CONTROL_MODES),
        "control_descriptions": dict(base.RHO_CONTROL_DESCRIPTION),
        "formal_seeds": list(FORMAL_SEEDS),
        "num_formal_seeds": len(FORMAL_SEEDS),
        "epochs": 30,
        "model_structure_changed": False,
        "new_trainable_parameters_added": False,
        "event_protocol_changed": False,
        "threshold_evaluation_pipeline_changed": False,
        "intended_changes_only": [
            "separate tested-rho residual-score path",
            "rho_ref-fixed reconstruction/residual-sparsity loss path",
            "rho_ref-fixed MQ-RGA path for recres_graph_fixed",
        ],
    }

    with open(
        OUTPUT_ROOT / "rho_control_protocol_audit.json",
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            protocol_audit,
            f,
            ensure_ascii=False,
            indent=2,
            default=json_default
        )

    if QUICK_TEST:
        modes = ["coupled"]
        rhos = [RHO_REF]
        seeds = [42]
        print(
            "\n[QUICK_TEST=True] Running only: "
            "coupled, rho=0.8, seed=42, epochs=30.\n"
            "Set QUICK_TEST=False for the formal 3×3×10 experiment.\n"
        )
    else:
        modes = list(CONTROL_MODES)
        rhos = list(RHO_VALUES)
        seeds = list(FORMAL_SEEDS)

    all_results: List[Dict] = []

    for mode in modes:
        for rho in rhos:
            for seed in seeds:

                result_json = seed_result_path(mode, rho, seed)

                if RESUME and result_json.exists():
                    print(
                        f"[RESUME] Skip finished: "
                        f"mode={mode}, rho={rho:.2f}, seed={seed}"
                    )
                    all_results.append(load_existing(result_json))
                    continue

                row = run_one(mode, rho, seed)
                all_results.append(row)

                # Incremental master JSON so an interrupted overnight run is safe.
                with open(
                    OUTPUT_ROOT / "rho_control_all_results.json",
                    "w",
                    encoding="utf-8"
                ) as f:
                    json.dump(
                        all_results,
                        f,
                        ensure_ascii=False,
                        indent=2,
                        default=json_default
                    )

                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()

    df = pd.DataFrame(all_results)

    if not df.empty:
        df.to_csv(
            OUTPUT_ROOT / "rho_control_seedwise_results.csv",
            index=False,
            encoding="utf-8-sig"
        )

        summary = build_summary(df)
        summary.to_csv(
            OUTPUT_ROOT / "rho_control_mean_std.csv",
            index=False,
            encoding="utf-8-sig"
        )

        formatted = build_formatted_summary(summary)
        formatted.to_csv(
            OUTPUT_ROOT / "rho_control_mean_std_formatted.csv",
            index=False,
            encoding="utf-8-sig"
        )

        identity = rho_ref_identity_audit(df)
        with open(
            OUTPUT_ROOT / "rho_ref_identity_audit.json",
            "w",
            encoding="utf-8"
        ) as f:
            json.dump(
                identity,
                f,
                ensure_ascii=False,
                indent=2,
                default=json_default
            )

        print("\n" + "=" * 88)
        print("RHO CONTROL FINISHED")
        print("=" * 88)
        print(
            "Seedwise :",
            OUTPUT_ROOT / "rho_control_seedwise_results.csv"
        )
        print(
            "Mean±std :",
            OUTPUT_ROOT / "rho_control_mean_std.csv"
        )
        print(
            "Formatted:",
            OUTPUT_ROOT / "rho_control_mean_std_formatted.csv"
        )
        print(
            "Audit    :",
            OUTPUT_ROOT / "rho_ref_identity_audit.json"
        )

        if not QUICK_TEST and identity.get("passed_tolerance_1e-8") is False:
            print(
                "\n[WARNING] rho_ref identity audit did not pass 1e-8. "
                "Inspect rho_ref_identity_audit.json before using the results."
            )


if __name__ == "__main__":
    main()
